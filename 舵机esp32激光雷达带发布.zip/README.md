# 舵机‑VL53L0X 机械激光雷达项目笔记

> 
> 硬件：Adafruit ESP32‑Feather（ESP32‑D0WD‑V3）
> 传感器：VL53L0X 激光测距；SG90 模拟舵机；micro‑ROS‑WiFi 发布 `/scan`（LaserScan）
> 架构：**硬件定时器产生扫描节拍 + Core1 FreeRTOS 任务做采集；micro‑ros 只负责发布，业务完全解耦**

## ✨项目成果

1. 舵机平滑**往返扫描（0° ↔ 120°）**，无急回冲击噪音；软件数组反转，输出数据严格满足 ROS `sensor_msgs/LaserScan` 角度递增协议，RViz2 正常可视化。
2. 扫描采集与 micro‑ROS/WiFi 完全解耦：WiFi/micro‑ros 断线，舵机 + 测距仍然持续运行。
3. 一帧 41 个扫描点；单步周期 60ms，整机扫描帧率约 0.4Hz，室内环境测距稳定。
4. 修复历史坑：栈内存野指针、往复扫描角度乱序、中断内禁止 I2C 操作、多任务共享缓冲区互斥保护。

## 🛠硬件接线

表格

| 器件引脚 | ESP32 Feather |
| --- | --- |
| VL53L0X‑VIN | 3.3V（严禁 5V） |
| VL53L0X‑GND | GND |
| VL53L0X‑SDA | GPIO21 |
| VL53L0X‑SCL | GPIO22 |
| SG90 舵机信号线 | GPIO13 |
| 全部模块 GND | 共地 |

> 
> I2C 配置：`Wire.begin(21,22); Wire.setClock(100000);`
> VL53L0X：单次测量模式，`setMeasurementTimingBudget(20000)`，关闭 continuous 连续模式。

## ⚙核心参数配置

```
#define PCOUNT          41        // 0‑120° step3°，总点数41
#define SCAN_MIN_ANGLE  0
#define SCAN_MAX_ANGLE  120
#define SCAN_STEP       3
#define HW_TICK_MS      60        //硬件定时器单步节拍ms，留有WiFi中断安全余量
```

- 舵机稳定延时：`vTaskDelay(pdMS_TO_TICKS(14))`；每步转动 3°，兼顾机械稳定与时序开销；**不可直接删除，servo.write 是非阻塞**。
- 硬件 Timer0 产生节拍，ISR 中断仅置标志位，**I2C、舵机、测距全部放到 Core1 任务上下文执行**。

## 🧠软件架构要点

1. **硬件定时器 ISR：只置`g_hw_tick_flag`，禁止任何库调用、I2C、Serial 打印**。
2. Core1 任务：等待 tick 标志，执行一步：舵机角度更新 → 延时机械稳定 → VL53 测距；
   - 正向扫描：数组直接使用；
   - 反向扫描：采集得到 120→0，调用`reverse_float_array()`反转数组，输出 0→120，适配 ROS 协议；
   - 采满一帧：`portENTER_CRITICAL()`保护拷贝至全局共享缓冲区，置`g_scan_done_flag = true`。
3. Core0 microros_spin_task：只检测`g_scan_done_flag`标志；**有新帧才 publish 一次 /scan，不会重复发送旧帧**。
4. publish 使用全局数组`g_pub_ranges[]`，杜绝局部栈内存失效脏数据 BUG。

> 
> ⚠️关键：ESP32 不能照搬 STM32 时序习惯，WiFi 硬件中断会抢占 CPU，时序必须预留 15ms 以上安全余量，8ms 余量在 WiFi 突发下会丢步、超时。

## 📌调试关键日志

```
[SCAN_STEP] angle:xx idx:xx dir:±1 cost:xx ms remain:xx ms dist:xx.xx
✅ ONE FRAME COMPLETE
📤 publish /scan ok
⚠️ VL53 timeout!     //出现该提示，增大HW_TICK_MS或者加大舵机稳定delay
[SCAN] reverse frame, reorder array //反向扫描数组反转
```

## 🚀RViz2 配置

- Topic：`/scan`
- Frame‑id：`laser_link`
- Range min：0.05；Range max：2.0

## 📋可扩展方向

1. 接入你之前 STM32 串口激光解析代码，增加第二套激光数据源；
2. 优化：舵机角度提前一拍输出，消除内部大块 vTaskDelay，进一步压缩单步耗时；
3. 异常处理：VL53 超时距离做过滤，剔除脏点；
4. 增加 OLED 本地显示扫描状态。

## ❗踩坑备忘

1. 不要在硬件定时器中断里面调用 Wire/I2C、Servo 库；
2. 多任务共享缓冲区，必须加`portENTER_CRITICAL`互斥锁；
3. ROS LaserScan 消息不支持乱序角度，往返扫描硬件顺滑，软件必须做数组反转；
4. publish 消息 ranges.data 不能绑定函数局部栈数组；
5. ESP32 WiFi 中断会抢占任务，时序不要压榨到极限。

> 
> 小项目圆满收官🎉，这套解耦架构后续可以移植到小车机器人上，配合 odom 完成导航避障。
> 如果后续需要合并电机控制、STM32 串口激光解析，可以直接在这个框架上叠加新的独立采集 + flag 发布单元。
