# generated from
# rosidl_cmake/cmake/template/rosidl_cmake_export_typesupport_targets.cmake.in

set(_exported_typesupport_targets
  "__rosidl_generator_c:fishbot_interfaces__rosidl_generator_c;__rosidl_typesupport_fastrtps_c:fishbot_interfaces__rosidl_typesupport_fastrtps_c;__rosidl_typesupport_introspection_c:fishbot_interfaces__rosidl_typesupport_introspection_c;__rosidl_typesupport_c:fishbot_interfaces__rosidl_typesupport_c;__rosidl_generator_cpp:fishbot_interfaces__rosidl_generator_cpp;__rosidl_typesupport_fastrtps_cpp:fishbot_interfaces__rosidl_typesupport_fastrtps_cpp;__rosidl_typesupport_introspection_cpp:fishbot_interfaces__rosidl_typesupport_introspection_cpp;__rosidl_typesupport_cpp:fishbot_interfaces__rosidl_typesupport_cpp;__rosidl_generator_py:fishbot_interfaces__rosidl_generator_py")

# populate fishbot_interfaces_TARGETS_<suffix>
if(NOT _exported_typesupport_targets STREQUAL "")
  # loop over typesupport targets
  foreach(_tuple ${_exported_typesupport_targets})
    string(REPLACE ":" ";" _tuple "${_tuple}")
    list(GET _tuple 0 _suffix)
    list(GET _tuple 1 _target)

    set(_target "fishbot_interfaces::${_target}")
    if(NOT TARGET "${_target}")
      # the exported target must exist
      message(WARNING "Package 'fishbot_interfaces' exports the typesupport target '${_target}' which doesn't exist")
    else()
      list(APPEND fishbot_interfaces_TARGETS${_suffix} "${_target}")
    endif()
  endforeach()
endif()
