#include "Kinematics.h"

// 用于将欧拉角转换为四元数。
void Kinematics::Euler2Quaternion(float roll, float pitch, float yaw, quaternion_t &q)
{
    // 传入机器人的欧拉角 roll、pitch 和 yaw。
    // 计算欧拉角的 sin 和 cos 值，分别保存在 cr、sr、cy、sy、cp、sp 六个变量中    
    // https://blog.csdn.net/xiaoma_bk/article/details/79082629
    double cr = cos(roll * 0.5);
    double sr = sin(roll * 0.5);
    double cy = cos(yaw * 0.5);
    double sy = sin(yaw * 0.5);
    double cp = cos(pitch * 0.5);
    double sp = sin(pitch * 0.5);
    // 计算出四元数的四个分量 q.w、q.x、q.y、q.z
    q.w = cy * cp * cr + sy * sp * sr;
    q.x = cy * cp * sr - sy * sp * cr;
    q.y = sy * cp * sr + cy * sp * cr;
    q.z = sy * cp * cr - cy * sp * sr;
}

// 用于将角度转换到 -π 到 π 的范围内
void Kinematics::TransAngleInPI(float angle, float &out_angle)
{
    // 如果 angle 大于 π，则将 out_angle 减去 2π
    out_angle = angle; // 先将输入角度赋值给输出
    if (angle > PI)
    {
        out_angle -= 2 * PI;
    }
    // 如果 angle 小于 -π，则将 out_angle 加上 2π
    else if (angle < -PI)
    {
        out_angle += 2 * PI;
    }
}

// 设置机器人的电机参数。该方法接受四个参数：电机的 ID、降速比、脉冲比和轮子直径。
void Kinematics::set_motor_param(uint8_t id, float per_pulse_distance)
{
    // motor_param_[id].id = id;                                   // 机器人电机的 ID 
    motor_param_[id].per_pulse_distance = per_pulse_distance;       // 电机的减速比
    // motor_param_[id].pulse_ration = pulse_ration;               // 电机的编码器脉冲比
    // motor_param_[id].wheel_diameter = wheel_diameter;           // 电机的轮子直径
    // 计算机器人电机每个编码器脉冲对应的行驶距离
    // // 公式为 轮子直径 乘以 圆周率 除以 减速比 乘以 编码器脉冲比
    // motor_param_[id].per_pulse_distance = (wheel_diameter * PI) / (reducation_ratio * pulse_ration);    
    // // 计算机器人电机的速度系数
    // // 公式为轮子直径乘以圆周率除以减速比乘以编码器脉冲比乘以 1000000（即将单位转换为米每秒）
    // motor_param_[id].speed_factor = (1000 * 1000) * (wheel_diameter * PI) / (reducation_ratio * pulse_ration);
    // Serial.printf("init motor param %d: %f=%f*PI/(%d*%d) speed_factor=%d\n", id, motor_param_[id].per_pulse_distance, wheel_diameter, reducation_ratio, pulse_ration, motor_param_[id].speed_factor);
}

// 用于设置机器人的运动学参数。该方法接受一个参数：轮子之间的距离（即轮距），并将其保存到类中的 wheel_distance_ 变量中
void Kinematics::set_wheel_distance(float wheel_distance)
{
    wheel_distance_ = wheel_distance;
}

void Kinematics::update_bot_odom(uint32_t dt)
{
    static float linear_speed, angular_speed;
    float dt_s = (float)(dt / 1000) / 1000;

    this->kinematic_forward(motor_param_[0].motor_speed, motor_param_[1].motor_speed, linear_speed, angular_speed);

    odom_.angular_speed = angular_speed;
    odom_.linear_speed = linear_speed / 1000; // /1000（mm/s 转 m/s）

    odom_.yaw += odom_.angular_speed * dt_s;

    Kinematics::TransAngleInPI(odom_.yaw, odom_.yaw);
    

    /*更新x和y轴上移动的距离*/
    float delta_distance = odom_.linear_speed * dt_s; // 单位m
    odom_.x += delta_distance * std::cos(odom_.yaw);
    odom_.y += delta_distance * std::sin(odom_.yaw);

}

// void Kinematics::TransAngleInPI(float angle, float &out_angle)
// {
//     if (angle > PI)
//     {
//         out_angle -= 2 * PI;
//     }
//     else if (angle < -PI)
//     {
//         out_angle += 2 * PI;
//     }
// }

odom_t &Kinematics::odom()
{
    return odom_;
}



// void Kinematics::update_motor_ticks_old(uint64_t current_time, uint64_t motor_tick1, uint64_t motor_tick2)
// {
//     // 首次调用时初始化last_update_time，避免dt过大
//     if (last_update_time == 0) {
//         last_update_time = current_time;
//         return; // 首次不计算速度，避免dt=0
//     }
//     // 计算时间差dt（单位：毫秒）
//     uint64_t dt = current_time - last_update_time;
//     // 防止dt=0导致除零错误
//     if (dt == 0) {
//         Serial.println("Warning: dt=0, skip speed calculation");
//         return;
//     }
//     // 编码器读数变化量
//     uint64_t dtick1 = motor_tick1 - motor_param_[0].last_encoder_tick;
//     uint64_t dtick2 = motor_tick2 - motor_param_[1].last_encoder_tick;
    
//     // 计算电机速度（单位：mm/s）
//     motor_param_[0].motor_speed = (float(dtick1) * motor_param_[0].per_pulse_distance * 1000.0f) / float(dt);
//     motor_param_[1].motor_speed = (float(dtick2) * motor_param_[1].per_pulse_distance * 1000.0f) / float(dt);
    

//     // 更新上次编码器读数和时间
//     motor_param_[0].last_encoder_tick = motor_tick1;
//     motor_param_[1].last_encoder_tick = motor_tick2;
//     last_update_time = current_time;
    
//     // 更新里程计
//     this->update_bot_odom_(dt);
// }


// 入参改为：delta_tick1、delta_tick2 为MTEP输出的50ms编码器增量(int32，可负)
void Kinematics::update_motor_ticks( int32_t delta_tick1, int32_t delta_tick2)
{
    const uint64_t dt_ms = 50; // MTEP固定50ms上报周期

    // 计算电机速度 mm/s
    motor_param_[0].motor_speed = (float(delta_tick1) * motor_param_[0].per_pulse_distance * 1000.0f) / float(dt_ms);
    motor_param_[1].motor_speed = (float(delta_tick2) * motor_param_[1].per_pulse_distance * 1000.0f) / float(dt_ms);

    // 注意：这里不再保存last_encoder_tick，增量由外部MTEP提供
    // 里程计：传入dt_ms，内部使用delta_tick1/delta_tick2做积分
    this->update_bot_odom_(dt_ms);
}

void Kinematics::update_odom_quat()
{
    float half_yaw = odom_.yaw * 0.5f;
    odom_.quaternion.w = cosf(half_yaw);
    odom_.quaternion.z = sinf(half_yaw);
    odom_.quaternion.x = 0.0f;
    odom_.quaternion.y = 0.0f;
}



// void Kinematics::update_bot_odom_(uint32_t dt)
// {
//     float linear_speed, angular_speed;
//     // dt是毫秒，转换为秒：dt / 1000.0f
//     float dt_s = float(dt) / 1000.0f;
    
//     // 前向运动学计算线速度、角速度
//     this->kinematic_forward(motor_param_[0].motor_speed, motor_param_[1].motor_speed, linear_speed, angular_speed);
    
//     // 里程计更新
//     odom_.angular_speed = angular_speed;
//     odom_.linear_speed = linear_speed / 1000; // mm/s 转换为 m/s

//     // 更新偏航角（弧度）
//     odom_.yaw += odom_.angular_speed * dt_s;
//     // 角度归一化到[-π, π]
//     Kinematics::TransAngleInPI(odom_.yaw, odom_.yaw);

//     // 更新x/y坐标（单位：米）
//     float delta_distance = odom_.linear_speed * dt_s; // 米
//     odom_.x += delta_distance * cos(odom_.yaw);
//     odom_.y += delta_distance * sin(odom_.yaw);

//     // 调试打印
//     //Serial.printf("delta_distance: %f m, yaw: %f rad, x: %f m, y: %f m\n", delta_distance, odom_.yaw, odom_.x, odom_.y);
// }


void Kinematics::update_bot_odom_(uint32_t dt)
{
    float linear_speed, angular_speed;
    float dt_s = float(dt) / 1000.0f;
    this->kinematic_forward(motor_param_[0].motor_speed, motor_param_[1].motor_speed, linear_speed, angular_speed);

    odom_.angular_speed = angular_speed;
    odom_.linear_speed = linear_speed / 1000; // mm/s → m/s

    odom_.yaw += odom_.angular_speed * dt_s;
    Kinematics::TransAngleInPI(odom_.yaw, odom_.yaw);

    float delta_distance = odom_.linear_speed * dt_s;
    odom_.x += delta_distance * cosf(odom_.yaw);
    odom_.y += delta_distance * sinf(odom_.yaw);

    // ✅关键：yaw更新完成，刷新结构体内部quaternion
    update_odom_quat();
}





// 机器人运动学模型中的逆运动学函数，用于将机器人的线速度和角速度转换为两个轮子的转速。
void Kinematics::kinematic_inverse(float linear_speed, float angular_speed, float &out_wheel1_speed, float &out_wheel2_speed)
{
    // 计算左轮的转速 out_wheel1_speed，公式为 线速度 减去 角速度乘以轮距的一半
    out_wheel1_speed =
        linear_speed - (angular_speed * wheel_distance_) / 2.0;
    // 计算右轮的转速 out_wheel2_speed，公式为 线速度 加上 角速度乘以轮距的一半。
    out_wheel2_speed =
        linear_speed + (angular_speed * wheel_distance_) / 2.0;
}

// 用于计算机器人的线速度和角速度。
void Kinematics::kinematic_forward(float wheel1_speed, float wheel2_speed, float &linear_speed, float &angular_speed)
{
    // 两轮转速之和除以2
    linear_speed = (wheel1_speed + wheel2_speed) / 2.0;
    // 两轮转速之差除以轮距
    angular_speed =
        (wheel2_speed - wheel1_speed) / wheel_distance_;
}

// 用于获取机器人的位置和姿态信息
// odom_t &Kinematics::odom()
// {
//     // 调用 Euler2Quaternion 函数，将机器人的欧拉角 yaw 转换为四元数 quaternion。
//     Kinematics::Euler2Quaternion(0, 0, odom_.yaw, odom_.quaternion);
//     // 返回机器人的位置和姿态信息 odom_
//     return odom_;
// }

// 传入电机的编号 id。返回该编号电机的速度
float Kinematics::motor_speed(uint8_t id)
{
    return motor_param_[id].motor_speed;
}