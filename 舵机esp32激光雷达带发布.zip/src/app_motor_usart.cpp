#include "app_motor_usart.hpp"
#define RXBUFF_LEN 256
uint8_t send_buff[50];
float g_Speed[4];
int Encoder_Offset[4];
int Encoder_Now[4];
//MTEP 50ms编码器增量
int Encoder_Delta[4] = {0,0,0,0};
uint8_t g_recv_flag;
uint8_t g_recv_buff[RXBUFF_LEN];
uint8_t g_recv_buff_deal[RXBUFF_LEN];

void send_motor_type(motor_type_t data)
{
	sprintf((char*)send_buff,"$mtype:%d#",data);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_motor_deadzone(uint16_t data)
{
	sprintf((char*)send_buff,"$deadzone:%d#",data);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_pulse_line(uint16_t data)
{
	sprintf((char*)send_buff,"$mline:%d#",data);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_pulse_phase(uint16_t data)
{
	sprintf((char*)send_buff,"$mphase:%d#",data);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_wheel_diameter(float data)
{
  char float_str[16];
  dtostrf(data, 6, 3, float_str);
	sprintf((char*)send_buff,"$wdiameter:%s#",float_str);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_motor_PID(float P,float I,float D)
{
	sprintf((char*)send_buff,"$mpid:%.3f,%.3f,%.3f#",P,I,D);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void send_upload_data(bool ALLEncoder_Switch,bool TenEncoder_Switch,bool Speed_Switch)
{
	//sprintf((char*)send_buff,"$upload:%d,%d,%d#",ALLEncoder_Switch,TenEncoder_Switch,Speed_Switch);
	//Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
    // 替换 send_upload_data(true,false,false);
    uint8_t cmd[]="$upload:1,1,0#";
    Send_Motor_ArrayU8(cmd,sizeof(cmd)-1); //-1 剔除字符串末尾'\0'
    delay(400);

}
void Contrl_Speed(int16_t M1_speed,int16_t M2_speed,int16_t M3_speed,int16_t M4_speed)
{
	sprintf((char*)send_buff,"$spd:%d,%d,%d,%d#",M1_speed,M2_speed,M3_speed,M4_speed);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}
void Contrl_Pwm(int16_t M1_pwm,int16_t M2_pwm,int16_t M3_pwm,int16_t M4_pwm)
{
	sprintf((char*)send_buff,"$pwm:%d,%d,%d,%d#",M1_pwm,M2_pwm,M3_pwm,M4_pwm);
	Send_Motor_ArrayU8(send_buff, strlen((char*)send_buff));
}

// 替换strtok，安全分割逗号，不使用静态全局
static int safe_split_comma(char *buf, char **out_arr, int max_cnt)
{
    int cnt = 0;
    char *p = buf;
    out_arr[cnt++] = p;
    while(*p != '\0' && cnt < max_cnt)
    {
        if(*p == ',')
        {
            *p = '\0';
            p++;
            out_arr[cnt++] = p;
        }else{
            p++;
        }
    }
    return cnt;
}

bool isValidNumbers(const char* str)
{
    for(int i=0;i<4;i++)
    {
        if(*str == '-') str++;
        if(!isdigit((unsigned char)*str)) return false;
        while(isdigit((unsigned char)*str)) str++;
        if(i<3)
        {
            if(*str != ',') return false;
            str++;
        }
    }
    return (*str == '\0');
}

// void Deal_Control_Rxtemp_old(uint8_t rxtemp)
// {
// 	static u8 step = 0;
// 	static u8 start_flag = 0;
// 	if(rxtemp == '$' && start_flag == 0)
// 	{
// 		start_flag = 1;
// 		memset(g_recv_buff,0,RXBUFF_LEN);
// 	}
// 	else if(start_flag == 1)
// 	{
// 		if(rxtemp == '#')
// 		{
// 			start_flag = 0;
// 			step = 0;
// 			g_recv_flag = 1;
// 			if (strncmp("MAll:",(char*)g_recv_buff,5)==0 ||
// 			    strncmp("MTEP:",(char*)g_recv_buff,5)==0 ||
// 			    strncmp("MSPD:",(char*)g_recv_buff,5)==0)
// 			{
// 				if (isValidNumbers((char*)g_recv_buff + 5))
// 				{
// 					memcpy(g_recv_buff_deal,g_recv_buff,RXBUFF_LEN);
// 				}
// 			}
// 			memset(g_recv_buff, 0, RXBUFF_LEN);
// 		}
// 		else
// 		{
// 			if(step >= RXBUFF_LEN)
// 			{
// 				start_flag = 0;
// 				step = 0;
// 				memset(g_recv_buff,0,RXBUFF_LEN);
// 			}
// 			else
// 			{
// 				g_recv_buff[step] = rxtemp;
// 				step++;
// 			}
// 		}
// 	}
// }

void Deal_Control_Rxtemp(uint8_t rxtemp)
{
	static u8 step = 0;
	static u8 start_flag = 0;
	if(rxtemp == '$' && start_flag == 0)
	{
		start_flag = 1;
		memset(g_recv_buff,0,RXBUFF_LEN);
	}
	else if(start_flag == 1)
	{
		if(rxtemp == '#')
		{
			start_flag = 0;
			step = 0;
			g_recv_flag = 1;
			if (strncmp("MAll:",(char*)g_recv_buff,5)==0 ||
			    strncmp("MTEP:",(char*)g_recv_buff,5)==0 ||
			    strncmp("MSPD:",(char*)g_recv_buff,5)==0)
			{
				if (isValidNumbers((char*)g_recv_buff + 5))
				{
					memcpy(g_recv_buff_deal,g_recv_buff,RXBUFF_LEN);
				}
			}
			memset(g_recv_buff, 0, RXBUFF_LEN);
		}
		else
		{
			if(step >= RXBUFF_LEN)
			{
				start_flag = 0;
				step = 0;
				memset(g_recv_buff,0,RXBUFF_LEN);
			}
			else
			{
				g_recv_buff[step] = rxtemp;
				step++;
			}
		}
	}
}




void Deal_data_real(void)
{
    char* strArray[4];
    char tmp_buf[RXBUFF_LEN];
    int parse_cnt;
    if(strncmp("MAll",(char*)g_recv_buff_deal,4)==0)
    {
        strncpy(tmp_buf,(char*)g_recv_buff_deal+5,sizeof(tmp_buf)-1);
        tmp_buf[sizeof(tmp_buf)-1] = '\0';
        parse_cnt = safe_split_comma(tmp_buf, strArray,4);
        if(parse_cnt ==4)
        {
            Encoder_Now[0] = atoi(strArray[0]);
            Encoder_Now[1] = atoi(strArray[1]);
            Encoder_Now[2] = atoi(strArray[2]);
            Encoder_Now[3] = atoi(strArray[3]);
        }
    }
    else if(strncmp("MTEP",(char*)g_recv_buff_deal,4)==0)
    {
        //====MTEP：50ms编码器增量delta，直接是变化量====
        strncpy(tmp_buf,(char*)g_recv_buff_deal+5,sizeof(tmp_buf)-1);
        tmp_buf[sizeof(tmp_buf)-1] = '\0';
        parse_cnt = safe_split_comma(tmp_buf, strArray,4);
        if(parse_cnt ==4)
        {
            Encoder_Delta[0] = atoi(strArray[0]);
            Encoder_Delta[1] = atoi(strArray[1]);
            Encoder_Delta[2] = atoi(strArray[2]);
            Encoder_Delta[3] = atoi(strArray[3]);
        }
    }
    else if(strncmp("MSPD",(char*)g_recv_buff_deal,4)==0)
    {
        strncpy(tmp_buf,(char*)g_recv_buff_deal+5,sizeof(tmp_buf)-1);
        tmp_buf[sizeof(tmp_buf)-1] = '\0';
        parse_cnt = safe_split_comma(tmp_buf, strArray,4);
        if(parse_cnt ==4)
        {
            g_Speed[0] = atof(strArray[0]);
            g_Speed[1] = atof(strArray[1]);
            g_Speed[2] = atof(strArray[2]);
            g_Speed[3] = atof(strArray[3]);
        }
    }
}
