#include "bsp_motor_usart.hpp"

// 使用ESP32硬件UART2，GPIO16=TX2，GPIO17=RX2
HardwareSerial& motorSerial = Serial2;

void Usart2_init (void)
{
    // 电机驱动串口 115200 波特
    motorSerial.begin(115200, SERIAL_8N1, 17, 16);
    Serial.println("✅ Motor UART2 init RX=17 TX=16");
}

void Send_Motor_U8(uint8_t Data)
{
    motorSerial.write(Data);
}

void Send_Motor_ArrayU8(uint8_t *pData, uint16_t Length)
{
    for(uint16_t i=0;i<Length;i++){
        Send_Motor_U8(*pData++);
    }
}

void Motor_USART_Recieve(void)
{
    while(motorSerial.available()>0)
    {
        uint8_t Rx_Temp = (uint8_t)motorSerial.read();
        Deal_Control_Rxtemp(Rx_Temp);
    }
}
