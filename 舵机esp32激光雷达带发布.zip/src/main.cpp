#include <Arduino.h>
#include <micro_ros_platformio.h>
#include <WiFi.h>
#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <ESP32Servo.h>
#include <VL53L0X.h>
#include <sensor_msgs/msg/laser_scan.h>
#include <nav_msgs/msg/odometry.h>
#include <geometry_msgs/msg/twist.h>
#include <micro_ros_utilities/string_utilities.h>
#include <Wire.h>
#include "Kinematics.h"
#include "PidController.h"
#include "app_motor_usart.hpp"
#include "bsp_motor_usart.hpp"
#include "micro_ros_transport_serial.h"
#include "micro_ros_transport_wifi_udp.h"

/*==== micro‑ROS ====*/
rcl_publisher_t publisher;
rcl_publisher_t odom_publisher;
rcl_subscription_t twist_subscriber;
rcl_timer_t timer;

rclc_executor_t executor;
rclc_support_t support;
rcl_allocator_t allocator;
rcl_node_t node;

sensor_msgs__msg__LaserScan pub_msg;
geometry_msgs__msg__Twist twist_msg;
nav_msgs__msg__Odometry odom_msg;

// ------------------- 硬件定时器55ms滴答（扫描，与micro‑ros完全解耦） -------------------
hw_timer_t *scan_timer = NULL;
portMUX_TYPE timer_mux = portMUX_INITIALIZER_UNLOCKED;
volatile bool g_hw_tick_flag = false;   //55ms滴答标志，定时器中断置位

void IRAM_ATTR scan_timer_isr(void)
{
    portENTER_CRITICAL_ISR(&timer_mux);
    g_hw_tick_flag = true;
    portEXIT_CRITICAL_ISR(&timer_mux);
}

// ------------------- 扫描参数 -------------------
#define PCOUNT          41
#define SERVO_PIN       13
#define SERVO_MIN_PULSE 500
#define SERVO_MAX_PULSE 2500
#define SCAN_MIN_ANGLE  0
#define SCAN_MAX_ANGLE  120
#define SCAN_STEP       3
#define HW_TICK_MS      55

Servo servo1;
VL53L0X sensor;

static float scan_work_buf[PCOUNT];      //Core1内部工作缓冲区
float g_scan_buffer[PCOUNT];             //跨任务共享完整帧
float g_pub_ranges[PCOUNT];              //publish专用全局数组
portMUX_TYPE scan_mux = portMUX_INITIALIZER_UNLOCKED;
volatile bool g_scan_done_flag = false;  //一帧采集完成标志

static int g_cur_angle = SCAN_MIN_ANGLE;
static int g_data_idx  = 0;

// ------------------- 电机控制全局 -------------------
PidController pid_Controller[2];
Kinematics kinematics;

float target_Linear_speed=0.03f;
float target_angular_speed=0.0f;
float out_left_speed;
float out_right_speed;

// ------------------- 函数声明 -------------------
void scan_task_func(void *param);
void setServoAngle(int angle);
float get_distance_nonblock(int angle, uint32_t max_wait_ms);
bool check_and_publish_scan(void);

void motor_task_func(void *param);
void loop_motor();
void odom_publisher_timer_callback(rcl_timer_t *timer, int64_t last_call_time);
void twist_subscription_callback(const void *msgin);

void microros_spin_task(void *param);

// I2C总线恢复，SDA锁死NACK 263时调用
bool i2c_recover(int sda, int scl)
{
  pinMode(sda, OUTPUT_OPEN_DRAIN);
  pinMode(scl, OUTPUT_OPEN_DRAIN);
  digitalWrite(sda, HIGH);
  digitalWrite(scl, HIGH);
  delayMicroseconds(10);
  for(int i = 0; i < 10; i++)
  {
    digitalWrite(scl, LOW);
    delayMicroseconds(10);
    digitalWrite(scl, HIGH);
    delayMicroseconds(10);
    if(digitalRead(sda)) break;
  }
  Wire.begin(sda, scl);
  Wire.setClock(100000);
  return digitalRead(sda);
}

// ------------------- 扫描工具函数 -------------------
void setServoAngle(int angle)
{
    angle = constrain(angle, SCAN_MIN_ANGLE, SCAN_MAX_ANGLE);
    servo1.write(angle);
}

float get_distance_nonblock(int angle, uint32_t max_wait_ms)
{
  setServoAngle(angle);
  vTaskDelay(pdMS_TO_TICKS(12)); //舵机稳定时间
  uint16_t dist_mm = sensor.readRangeSingleMillimeters();

  if( sensor.timeoutOccurred() || (sensor.last_status != 0) )
  {
    Serial.printf("⚠️ VL53 step timeout/err status:%d skip point\n", sensor.last_status);
    if(sensor.last_status != 0)
    {
      Serial.println("Try I2C bus recover");
      i2c_recover(21,22);
    }
    return 2.0f;
  }
  float dist_m = dist_mm / 1000.0f;
  return constrain(dist_m, 0.05f, 2.0f);
}

void reverse_float_array(float *arr, int len)
{
    int i = 0;
    int j = len - 1;
    while(i < j)
    {
        float tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
        i++;
        j--;
    }
}

void scan_task_func(void *param)
{
  int scan_direction = 1;
  g_cur_angle = SCAN_MIN_ANGLE;
  g_data_idx  = 0;
  for(;;)
  {
    bool tick = false;
    portENTER_CRITICAL(&timer_mux);
    if(g_hw_tick_flag)
    {
        g_hw_tick_flag = false;
        tick = true;
    }
    portEXIT_CRITICAL(&timer_mux);

    if(tick)
    {
        uint32_t step_start = millis();
        float d = get_distance_nonblock(g_cur_angle,40);
        uint32_t step_end = millis();
        uint32_t step_cost = step_end - step_start;
        int32_t step_remain = HW_TICK_MS - step_cost;

        Serial.printf("A:%d :%d ms D:%.2f\n",
            g_cur_angle, step_remain, d);

        scan_work_buf[g_data_idx++] = d;

        if(g_data_idx >= PCOUNT)
        {
            if(scan_direction == -1)
            {
                Serial.println("[SCAN] reverse frame, reorder array");
                reverse_float_array(scan_work_buf, PCOUNT);
            }
            portENTER_CRITICAL(&scan_mux);
            memcpy(g_scan_buffer, scan_work_buf, sizeof(g_scan_buffer));
            g_scan_done_flag = true;
            portEXIT_CRITICAL(&scan_mux);
            Serial.println("✅ ONE FRAME COMPLETE");

            scan_direction = -scan_direction;
            g_data_idx  = 0;
            g_cur_angle = (scan_direction == 1) ? SCAN_MIN_ANGLE : SCAN_MAX_ANGLE;
        }
        else
        {
            g_cur_angle += scan_direction * SCAN_STEP;
        }
    }
    vTaskDelay(pdMS_TO_TICKS(1));
  }
}

bool check_and_publish_scan(void)
{
    bool published = false;
    portENTER_CRITICAL(&scan_mux);
    if(g_scan_done_flag)
    {
        memcpy(g_pub_ranges, g_scan_buffer, sizeof(g_pub_ranges));
        g_scan_done_flag = false;
        portEXIT_CRITICAL(&scan_mux);

        int64_t current_time = rmw_uros_epoch_millis();
        pub_msg.header.stamp.sec = current_time / 1000;
        pub_msg.header.stamp.nanosec = (current_time % 1000) * 1000000;
        pub_msg.ranges.data = g_pub_ranges;
        pub_msg.ranges.capacity = PCOUNT;
        pub_msg.ranges.size = PCOUNT;

        rcl_ret_t rc = rcl_publish(&publisher, &pub_msg, NULL);
        if(rc == RCL_RET_OK)
        {
            Serial.println("📤 publish /scan ok");
            published = true;
        }
    }
    else
    {
        portEXIT_CRITICAL(&scan_mux);
    }
    return published;
}

// ------------------- 电机、odom、cmd_vel 回调 -------------------
void twist_subscription_callback(const void *msgin)
{
  const geometry_msgs__msg__Twist *msg = (const geometry_msgs__msg__Twist *)msgin;
  float target_motor_speed1, target_motor_speed2;
  kinematics.kinematic_inverse(msg->linear.x * 1000, msg->angular.z, target_motor_speed1, target_motor_speed2);
  pid_Controller[0].update_target(target_motor_speed1);
  pid_Controller[1].update_target(target_motor_speed2);
  Serial.printf("recv cmd_vel(%.2f,%.2f) motor(%.2f,%.2f)\n", msg->linear.x * 1000, msg->angular.z, target_motor_speed1, target_motor_speed2);
}

void odom_publisher_timer_callback(rcl_timer_t *timer, int64_t last_call_time)
{
  RCLC_UNUSED(last_call_time);
  if (timer != NULL)
  {
    odom_t odom = kinematics.odom();
    int64_t stamp = rmw_uros_epoch_millis();
    odom_msg.header.stamp.sec = stamp / 1000;
    odom_msg.header.stamp.nanosec = (stamp % 1000) * 1000000;

    odom_msg.pose.pose.position.x = odom.x;
    odom_msg.pose.pose.position.y = odom.y;
    odom_msg.pose.pose.orientation.w = odom.quaternion.w;
    odom_msg.pose.pose.orientation.x = odom.quaternion.x;
    odom_msg.pose.pose.orientation.y = odom.quaternion.y;
    odom_msg.pose.pose.orientation.z = odom.quaternion.z;

    odom_msg.twist.twist.angular.z = odom.angular_speed;
    odom_msg.twist.twist.linear.x = odom.linear_speed;

    rcl_publish(&odom_publisher, &odom_msg, NULL);
  }
}

void loop_motor()
{
    Motor_USART_Recieve();
    bool new_frame = false;
    if(g_recv_flag == 1)
    {
        g_recv_flag = 0;
        new_frame = true;
        Deal_data_real();
        Serial.printf("[NEW_FRAME] Encoder_Delta[0]=%d , Encoder_Delta[2]=%d\n", Encoder_Delta[0], Encoder_Delta[2]);
    }
    static float out_motor_speed[2];
    if(new_frame)
    {
        kinematics.update_motor_ticks((int64_t)Encoder_Delta[0], (int64_t)Encoder_Delta[2]);
    }
    float fb_speed_left  = kinematics.motor_speed(0);
    float fb_speed_right = kinematics.motor_speed(1);
    out_motor_speed[0] = pid_Controller[0].update(fb_speed_left);
    out_motor_speed[1] = pid_Controller[1].update(fb_speed_right);

    Serial.printf("[MOTOR_CTRL] fb_L=%.2f fb_R=%.2f | pid_out_L=%.2f pid_out_R=%.2f | send_L=%d send_R=%d\n",
        fb_speed_left, fb_speed_right,
        out_motor_speed[0], out_motor_speed[1],
        (int16_t)out_motor_speed[0], (int16_t)out_motor_speed[1]);

    Contrl_Speed((int16_t)out_motor_speed[0], 0, (int16_t)out_motor_speed[1], 0);
    delay(50);
}

void motor_task_func(void *param)
{
  for(;;)
  {
    loop_motor();
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

#define RCSOFTCHECK(fn)                                                           \
  {                                                                               \
    rcl_ret_t temp_rc = fn;                                                       \
    if ((temp_rc != RCL_RET_OK))                                                  \
    {                                                                             \
      printf(                                                                     \
          "Failed status on line %d: %d. Continuing.\n", __LINE__, (int)temp_rc); \
    }                                                                             \
  }

bool setup_microros_wifi(String ssid, String password, String ip)
{
  IPAddress agent_ip;
  agent_ip.fromString(ip);
  size_t agent_port = 8888;
  set_microros_wifi_transports((char *)ssid.c_str(), (char *)password.c_str(), agent_ip, agent_port);
  delay(500);

  allocator = rcl_get_default_allocator();
  RCSOFTCHECK(rclc_support_init(&support, 0, NULL, &allocator));
  RCSOFTCHECK(rclc_node_init_default(&node, "laser_motor_node", "", &support));

  // /scan publisher
  RCSOFTCHECK(rclc_publisher_init_default(
      &publisher,
      &node,
      ROSIDL_GET_MSG_TYPE_SUPPORT(sensor_msgs, msg, LaserScan),
      "/scan"));

  // /odom publisher
  RCSOFTCHECK(rclc_publisher_init_default(
      &odom_publisher,
      &node,
      ROSIDL_GET_MSG_TYPE_SUPPORT(nav_msgs, msg, Odometry),
      "/odom"));

  // cmd_vel subscriber
  RCSOFTCHECK(rclc_subscription_init_default(
      &twist_subscriber,
      &node,
      ROSIDL_GET_MSG_TYPE_SUPPORT(geometry_msgs, msg, Twist),
      "cmd_vel"));

  // odom timer 50ms
  const unsigned int timer_timeout = 50;
  RCSOFTCHECK(rclc_timer_init_default(&timer, &support, RCL_MS_TO_NS(timer_timeout), odom_publisher_timer_callback));

  // executor 容量：订阅+timer，填3留余量
  RCSOFTCHECK(rclc_executor_init(&executor, &support.context, 3, &allocator));

  return true;
}

void microros_spin_task(void *param)
{
  while (true)
  {
    if (!rmw_uros_epoch_synchronized())
    {
      RCSOFTCHECK(rmw_uros_sync_session(1000));
      Serial.print("sync time\n");
      continue;
    }
    RCSOFTCHECK(rclc_executor_spin_some(&executor, RCL_MS_TO_NS(20)));
    check_and_publish_scan();
  }
}

void setup_motor()
{
  Serial.println("==== ENTER setup_motor ====");
  Usart2_init();
  send_upload_data(false,false,false);
  delay(100);
  send_motor_type(MOTOR_TT_Encoder);
  delay(100);
  send_pulse_phase(45);
  delay(100);
  send_pulse_line(12);
  delay(100);
  send_wheel_diameter(65);
  delay(100);
  send_motor_deadzone(1250);
  send_upload_data(true,false,false);
  delay(200);
  Serial.println("✅ Motor board config done");

  pid_Controller[0].reset();
  pid_Controller[1].reset();
  pid_Controller[0].update_pid(0.07f, 0.25f, 0.08f);
  pid_Controller[1].update_pid(0.07f, 0.25f, 0.08f);
  pid_Controller[0].out_limit(-600, 600);
  pid_Controller[1].out_limit(-600, 600);

  kinematics.set_motor_param(0, 0.1051f);
  kinematics.set_motor_param(1, 0.1051f);
  kinematics.set_wheel_distance(175.0f);
  kinematics.kinematic_inverse(target_Linear_speed,target_angular_speed,out_left_speed,out_right_speed);
  pid_Controller[0].update_target(out_left_speed);
  pid_Controller[1].update_target(out_right_speed);
}

void setup()
{
    Serial.begin(115200);
    delay(500);
    Serial.printf("Free heap = %d bytes\n",ESP.getFreeHeap());

    // I2C VL53
    Wire.begin(21, 22);
    Wire.setClock(100000);
    Serial.println("✅ I2C 100KHz");

    //电机初始化 USART2
    setup_motor();

    //VL53 init
    sensor.setTimeout(50);
    if (!sensor.init())
    {
        Serial.println("❌ VL53 init FAIL");
        while (1) delay(1000);
    }

    //硬件扫描定时器
    scan_timer = timerBegin(0, 80, true);
    timerAttachInterrupt(scan_timer, &scan_timer_isr, true);
    timerAlarmWrite(scan_timer, HW_TICK_MS * 1000, true);
    timerAlarmEnable(scan_timer);
    Serial.printf("✅ HW timer init %dms tick\n",HW_TICK_MS);

    sensor.setMeasurementTimingBudget(20000);
    Serial.println("✅ VL53 ready（单次测量）");
    delay(800);

    //舵机初始化
    servo1.setPeriodHertz(50);
    servo1.attach(SERVO_PIN, SERVO_MIN_PULSE, SERVO_MAX_PULSE);
    servo1.write(SCAN_MIN_ANGLE);
    Serial.println("✅ Servo init");
    delay(1800);

    //micro‑ros wifi
    setup_microros_wifi("Galaxy M30sF6AF", "123456px", "192.168.43.177");

    //必须：把订阅、定时器加入executor，否则不触发
    RCSOFTCHECK(rclc_executor_add_subscription(&executor, &twist_subscriber, &twist_msg, &twist_subscription_callback, ON_NEW_DATA));
    RCSOFTCHECK(rclc_executor_add_timer(&executor, &timer));

    //laser scan msg frame_id
    pub_msg.header.frame_id = micro_ros_string_utilities_set(pub_msg.header.frame_id,"laser_link");
    pub_msg.angle_min  = SCAN_MIN_ANGLE  * PI / 180.0f;
    pub_msg.angle_max  = SCAN_MAX_ANGLE  * PI / 180.0f;
    pub_msg.angle_increment = SCAN_STEP * PI / 180.0f;
    pub_msg.range_min  = 0.05f;
    pub_msg.range_max  = 2.0f;
    pub_msg.scan_time  = (PCOUNT * HW_TICK_MS)/1000.0f;
    pub_msg.time_increment = HW_TICK_MS /1000.0f;

    //odom frame_id
    odom_msg.header.frame_id.data = (char*)"odom";
    odom_msg.child_frame_id = micro_ros_string_utilities_set(odom_msg.child_frame_id,"base_footprint");

    //创建全部3个任务
    xTaskCreatePinnedToCore(
        scan_task_func,
        "scan_task",
        8192,
        NULL,
        3,
        NULL,
        1
    );

    xTaskCreatePinnedToCore(
        motor_task_func,
        "motor_task",
        8192,
        NULL,
        2,
        NULL,
        0
    );

    xTaskCreatePinnedToCore(microros_spin_task, "microros_spin_task", 10240, NULL, 1, NULL, 0);

    Serial.println("📌 All task started");
}

void loop()
{
  vTaskDelay(pdMS_TO_TICKS(1000));
}
